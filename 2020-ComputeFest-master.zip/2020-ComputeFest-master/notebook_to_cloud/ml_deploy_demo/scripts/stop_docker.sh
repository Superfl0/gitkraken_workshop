#!/bin/bash

docker-compose -f docker-compose.yaml --project-name ml_deploy_demo down
